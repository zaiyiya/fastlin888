<h4 align="right">
  <a href="../README.md">简体中文</a> | <a href="README_en.md">English</a> | <strong>Русский</strong> | <a href="README_fa.md">فارسی</a> | <a href="README_ja.md">日本語</a> | <a href="README_ko.md">한국어</a>
</h4>

<h1 align="center">⚡ Bettbox</h1>
<p align="center">
  <strong>Another Better Network Toolbox</strong>
</p>

**Bettbox — это кроссплатформенный инструмент для маршрутизации сетевого трафика и отладки DNS на базе ядра Mihomo. Главный акцент — на превосходном пользовательском опыте: приложение создано для долгой стабильной работы, лёгкое, экономное к ресурсам и не собирает никаких данных.**

Bettbox означает Better Network Toolbox. Проект прошёл ручной аудит безопасности SignPath Foundation, а сборка для Windows подписана сертификатом подписи кода OV.

[![Latest Release](https://img.shields.io/github/v/release/appshubcc/Bettbox?style=for-the-badge&logo=github&color=238636&label=Release)](https://github.com/appshubcc/Bettbox/releases/latest) [![Core](https://img.shields.io/github/v/release/MetaCubeX/mihomo?style=for-the-badge&logo=go&logoColor=white&color=8A2BE2&label=Mihomo)](https://github.com/MetaCubeX/mihomo/releases/latest)

<p align="center">
  <img src="../snapshots/home.jpg" alt="Bettbox" />
</p>

---
### ✈️ Сообщество в Telegram

[![Telegram Group](https://img.shields.io/badge/Bettbox-Chat-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/bettbox_chat) [![Telegram Channel](https://img.shields.io/badge/Bettbox-Channel-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/appshub_channel)

---
## 🚀 Основные особенности

* **Готово к работе**: Подсказки по разрешениям, TUN и управляемый режим маршрутизации предустановлены — готово к использованию сразу после установки.
* **Лёгкость и плавность**: Низкое энергопотребление на мобильных устройствах, малая фоновая нагрузка на ПК и плавные анимации интерфейса.
* **Безопасность и доверие**: Ядро следует основной ветке Mihomo, на каждой платформе запрашиваются только минимально необходимые разрешения.
* **Отказоустойчивость и стабильность**: Оптимизированы граничные сценарии в экстремальных сетевых условиях на разных платформах; двойная проверка конфигурации подходит для длительной работы.
* **Архитектурная оптимизация**: Нативная поддержка ARM64 на ПК и постоянная поддержка совместимой (Compatible) версии для старых устройств.
* **Умный демон**: Умный автозапуск и остановка на разных платформах, адаптация к режиму сна Doze на мобильных устройствах и быстрое управление из системного трея на ПК.
* **Визуальные настройки**: Визуальная настройка параметров с мгновенным применением — даже новичкам не нужно вручную править конфигурацию.
* **Виджеты на главном экране**: Несколько продуманных встроенных виджетов позволяют следить за общим состоянием работы прямо с главного экрана.
* **Универсальный инструментарий**: Встроенные профессиональные инструменты отладки сети и DNS-маршрутизации — состояние сети видно с первого взгляда.
* **Персонализация**: Цветовые темы в стиле Material Design, настраиваемые значки и заголовки, а также 30 анимаций теста скорости.
* **Экосистема и расширения**: Внешние JS-скрипты переопределения получают графический интерфейс; встроен высокопроизводительный редактор Code-forge.
* **Нулевой риск приватности**: Открытый исходный код, без рекламы, полностью автоматизированный и публично проверяемый CI/CD, никакого сбора данных в фоне.
* **Ориентация на сообщество**: Мы внимательно относимся к отзывам сообщества, развиваемся вместе с активными пользователями и оперативно отвечаем на качественные Issue.

---
## 🛠️ Установка и загрузка

Перейдите на страницу **[[Releases]](https://github.com/appshubcc/Bettbox/releases)**, чтобы скачать актуальный установочный пакет для вашей платформы и системы:

* **Поддержка настольных ПК**: 
  * **Windows 8.1+:** (x64 / arm64)
  * **Linux Kernel 5.4+:** (x64 / arm64)
  * **macOS 12.0+:** (Intel / Apple Silicon)
* **Мобильные устройства и другие**: 
  * **Android 8.0+:** (ARMv8 / ARMv7 / x86_64 / Universal) 
  * **Android TV:** Полная адаптация под большие экраны, доступна 32-битная версия ARMv7
  * **HarmonyOS NEXT:** Стабильно работает в связке с [[ZhuoYiTong]](https://harmonyos.cool/android-app)

**Пакеты от сообщества Linux:**<br>
* **ArchLinux:** <code>yay -S bettbox-bin</code> или <code>paru -S bettbox-bin</code> (поддерживается [lyj404](https://github.com/lyj404/bettbox-aur))<br>
* **AMD64=v1 (Совместимая версия):** <code>yay -S bettbox-compatible-bin</code> или <code>paru -S bettbox-compatible-bin</code> (поддерживается [VillagerTom](https://github.com/VillagerTom))

---
## 💡 Часто задаваемые вопросы

1. **Системные требования и совместимость**:
   - На устройствах Android убедитесь, что приложению предоставлены достаточные разрешения для работы в фоновом режиме; система должна быть не ниже Android 8.0+.
   - Для старых ПК выбирайте соответствующую версию Compatible в зависимости от набора инструкций процессора.
   - Безопасность: Bettbox полностью прозрачен и открыт, код прошёл авторитетный аудит безопасности SignPath, сбор персональных данных отсутствует.

2. **Права администратора на ПК и режим TUN**:
   - В установщике Windows права администратора преднастроены заранее — в повседневном использовании повторная авторизация вручную не требуется.
   - При включении виртуального адаптера TUN на macOS / Linux введите правильный системный пароль по запросу для подтверждения прав.
   - При возникновении других ошибок убедитесь, что порты не заняты другими прокси-программами, и приложите логи Debug при отправке отзыва.

3. **Руководство по первой установке на macOS**:
   - Скачайте пакет `.dmg` в соответствии с вашей платформой (Intel / Apple Silicon), откройте его и перетащите значок Bettbox в папку Программы (Applications).
   - **Обход системной защиты Gatekeeper** ([сертификат Apple Developer в настоящее время не приобретён](https://support.apple.com/en-us/102445)):
     - **Рекомендуется**: В папке «Программы» **нажмите правой кнопкой мыши на значок Bettbox и выберите «Открыть»**, затем подтвердите нажатием «Открыть» в системном диалоговом окне.
     - **Альтернатива**: Если запуск заблокирован, откройте «Системные настройки -> Конфиденциальность и безопасность», найдите Bettbox и нажмите «Подтвердить вход».
   - При первом включении режима TUN система запросит пароль; введите его, чтобы разрешить создание виртуального сетевого интерфейса.

4. **Импорт подписок и устранение неполадок**:
   - Если импорт не удался, сначала сбросьте ссылку на подписку в личном кабинете провайдера и повторите попытку.
   - Если проблема не устранена, сверьте формат узлов с поставщиком услуг; если подтвердится ошибка клиента, создайте Issue на GitHub.

---
## 💻 Разработка, сборка и адаптация UI

Пример сборки для платформы Windows:

* Системные требования: Windows 10 или новее
* Зависимости: Git, Visual Studio, Flutter 3.47.x, Golang, Inno Setup, Rust
```bash
* flutter pub get (получение зависимостей)
* dart .\setup.dart windows --arch amd64 --out core (сборка только ядра Core)
* dart .\setup.dart windows --arch amd64 --out app --compatible (опциональная сборка Compatible)
* После завершения сборки готовые файлы будут находиться в папке `dist/`
```

Адаптация пользовательских скриптов под графический интерфейс:

* Bettbox поддерживает визуальную адаптацию UI для внешних скриптов переопределения (override). Например, для **[скрипта/конфигурации](https://github.com/AIsouler/MyClash)** от AIsouler достаточно добавить в первую строку скрипта следующее объявление для прямой связи со встроенными переключателями:
* <code>const Compatible_With_Bettbox = { ruleOptionsEnable: true };</code>
* Если переключатели скрипта содержат группы политик и другие функции, имена переключателей групп политик можно объявить через `policyGroupOptions`; необъявленные переключатели будут автоматически помещены в подменю «⚙️ Другие настройки»:

```js
const Compatible_With_Bettbox = {
  ruleOptionsEnable: true,
  // Объявление имен переключателей групп политик; должны точно совпадать с ключами в ruleOptionsEnable
  policyGroupOptions: ['🚀 节点选择', '🛑 广告拦截'],
};
```
* Если `policyGroupOptions` не объявлен или имена не совпадают, все переключатели будут отображаться на одном уровне.

---
### 🛩️ Рекомендуемые сервисы
#### Выделенные линии IEPL  〢  [百变小樱 (BBXY)](https://www.bbxy01.com/v2/register?code=c09R)  〢  [白月光 (BaiYueGuang)](https://www.sibker.com/register?invite_code=YZq6L5zd)  〢  [Ytoo](https://y-too.net/aff.php?aff=10354)
--------------------------------
#### Бюджетные прямые линии  〢  [良心云 (Liangxin Cloud)](https://xn--9kqz23b19z.com/#/register?code=VTnrQYAj)  〢  [吹雪云 (Chuixue Cloud)](https://xn--9kqs1lo79d.com/#/register?code=skKMTab7)  〢  [一分 (YiFen)](https://xn--4gqx1hgtfdmt.com/#/register?code=AuCiXprV) 
--------------------------------
#### Эксклюзивный промокод со скидкой 32% для 百变小樱: bettbox68 , подробнее: [Описание](https://t.me/appshub_channel/381)
--------------------------------

**Краткий обзор** : ❚ ❚ Приведенные выше ссылки в основном используются лично или обсуждаются и рекомендуются в сообществе TG. Они представлены здесь исключительно в качестве партнерских (AFF) ссылок (Примечание: при покупке сторонних сервисов по ссылкам разработчик получает небольшую комиссию в поддержку проекта), что не является гарантией качества услуг. Пожалуйста, оценивайте риски и выбирайте осознанно.

---
### ☕ Поддержка и донаты

**Если проект оказался полезным, вы можете поддержать разработку одним из следующих способов или воспользоваться [реферальными ссылками](../README.md#%EF%B8%8F-%E6%8E%A8%E8%8D%90%E6%9C%8D%E5%8A%A1):**

* TRON (TRC-20)： <code>TCkTtZfF2WrciZLaJj3e1aqrh3zdTnCkDa</code>
* Bitcoin： <code>bc1qu950cl6035qvllmzk6cfw3l30j2lg3cq9n6g6h</code>

---
## ❤️ Благодарности

<table>
  <tr>
    <td>
      <img alt="SignPath" src="https://signpath.org/assets/favicon-50x50.png" />
    </td>
    <td>
    Free code signing on Windows provided by <a href="https://signpath.io">SignPath.io</a>, certificate by <a href="https://signpath.org/">SignPath Foundation</a>
    </td>
  </tr>
</table>

* **[FlClash GUI](https://github.com/chen08209/FlClash)** (Проект берет свое начало от превосходного открытого проекта FlClash; отдаем дань уважения новаторским исследованиям и вкладу автора)
* **[Mihomo Core](https://github.com/MetaCubeX/mihomo)** (Мощное и гибкое ядро)

Благодарим всех [Участников](https://github.com/appshubcc/Bettbox/graphs/contributors), внесших вклад в проект, а также следующие открытые проекты за вдохновение и практические решения:

[Zashboard](https://github.com/Zephyruso/zashboard), [CMFA](https://github.com/MetaCubeX/ClashMetaForAndroid), [Sparkle](https://github.com/xishang0128/sparkle), [SFA](https://github.com/SagerNet/sing-box-for-android), [HUSI](https://github.com/xchacha20-poly1305/husi), [V2rayN](https://github.com/2dust/v2rayN), [Bett-rules](https://github.com/appshubcc/bett-rules)

---
## 📈 Популярность проекта

<p align="center">
  <a href="https://www.star-history.com/?repos=appshubcc%2FBettbox&type=timeline&legend=top-left">
    <picture>
      <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/chart?repos=appshubcc/Bettbox&type=date&theme=dark&legend=top-left" />
      <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/chart?repos=appshubcc/Bettbox&type=date&legend=top-left" />
      <img alt="Star History Chart" src="https://api.star-history.com/chart?repos=appshubcc/Bettbox&type=date&legend=top-left" />
    </picture>
  </a>
</p>

---
## 📄 Лицензия

Этот проект распространяется под лицензией [GPL-3.0 License](../LICENSE).
