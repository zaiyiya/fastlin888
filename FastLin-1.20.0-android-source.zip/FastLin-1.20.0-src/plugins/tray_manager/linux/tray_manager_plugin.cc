#include "include/tray_manager/tray_manager_plugin.h"

#include <flutter_linux/flutter_linux.h>
#include <gtk/gtk.h>
#include <sys/utsname.h>

#ifdef HAVE_AYATANA
#include <libayatana-appindicator/app-indicator.h>
#else
#include <libappindicator/app-indicator.h>
#endif
#include <algorithm>
#include <cstring>
#include <map>

#define TRAY_MANAGER_PLUGIN(obj)                                     \
  (G_TYPE_CHECK_INSTANCE_CAST((obj), tray_manager_plugin_get_type(), \
                              TrayManagerPlugin))

TrayManagerPlugin* plugin_instance;

AppIndicator* indicator = nullptr;
GtkWidget* menu = nullptr;
bool is_menu_open_ = false;

struct _TrayManagerPlugin {
  GObject parent_instance;
  FlPluginRegistrar* registrar;
  FlMethodChannel* channel;
};

G_DEFINE_TYPE(TrayManagerPlugin, tray_manager_plugin, g_object_get_type())

// Gets the window being controlled.
GtkWindow* get_window(TrayManagerPlugin* self) {
  FlView* view = fl_plugin_registrar_get_view(self->registrar);
  if (view == nullptr)
    return nullptr;

  return GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(view)));
}

void _on_activate(GtkMenuItem* item, gpointer user_data) {
  gint id = GPOINTER_TO_INT(user_data);

  g_autoptr(FlValue) result_data = fl_value_new_map();
  fl_value_set_string_take(result_data, "id", fl_value_new_int(id));
  fl_method_channel_invoke_method(plugin_instance->channel,
                                  "onTrayMenuItemClick", result_data, nullptr,
                                  nullptr, nullptr);
}

static void _on_menu_mapped(GtkWidget* widget, gpointer user_data) {
  if (!is_menu_open_) {
    is_menu_open_ = true;
    fl_method_channel_invoke_method(plugin_instance->channel, "onMenuOpen",
                                    nullptr, nullptr, nullptr, nullptr);
  }
}

static void _on_menu_unmapped(GtkWidget* widget, gpointer user_data) {
  if (is_menu_open_) {
    is_menu_open_ = false;
    fl_method_channel_invoke_method(plugin_instance->channel, "onMenuClose",
                                    nullptr, nullptr, nullptr, nullptr);
  }
}

static const char* _lookup_string_or_empty(FlValue* value, const char* key) {
  FlValue* string_value = fl_value_lookup_string(value, key);
  if (string_value == nullptr) return "";
  return fl_value_get_string(string_value);
}

static GtkWidget* _create_menu_item_box(const char* label,
                                        const char* sublabel) {
  GtkWidget* box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 16);
  GtkWidget* left_label = gtk_label_new(label);
  GtkWidget* right_label = gtk_label_new(sublabel);

  gtk_label_set_xalign(GTK_LABEL(left_label), 0.0);
  gtk_label_set_xalign(GTK_LABEL(right_label), 1.0);
  gtk_widget_set_hexpand(left_label, TRUE);
  gtk_widget_set_margin_start(right_label, 24);

  gtk_box_pack_start(GTK_BOX(box), left_label, TRUE, TRUE, 0);
  gtk_box_pack_end(GTK_BOX(box), right_label, FALSE, FALSE, 0);

  return box;
}

static void _set_menu_item_text(GtkWidget* item, const char* label,
                                const char* sublabel) {
  if (!GTK_IS_BIN(item)) {
    return;
  }

  GtkWidget* child = gtk_bin_get_child(GTK_BIN(item));
  if (!GTK_IS_BOX(child)) {
    gtk_menu_item_set_label(GTK_MENU_ITEM(item), label);
    return;
  }

  GList* children = gtk_container_get_children(GTK_CONTAINER(child));
  GtkWidget* left_label = GTK_WIDGET(g_list_nth_data(children, 0));
  GtkWidget* right_label = GTK_WIDGET(g_list_nth_data(children, 1));

  if (left_label != nullptr && GTK_IS_LABEL(left_label)) {
    gtk_label_set_text(GTK_LABEL(left_label), label);
  }
  if (right_label != nullptr && GTK_IS_LABEL(right_label)) {
    gtk_label_set_text(GTK_LABEL(right_label), sublabel);
  }

  g_list_free(children);
}

static void _update_menu_labels(GtkWidget* menu_widget, FlValue* args) {
  FlValue* items_value = fl_value_lookup_string(args, "items");
  gint item_count = fl_value_get_length(items_value);

  GList* children = gtk_container_get_children(GTK_CONTAINER(menu_widget));
  gint gtk_count = g_list_length(children);
  gint min_count = item_count < gtk_count ? item_count : gtk_count;

  for (gint i = 0; i < min_count; i++) {
    FlValue* item_value = fl_value_get_list_value(items_value, i);
    GtkWidget* item = GTK_WIDGET(g_list_nth_data(children, i));

    const char* type =
        fl_value_get_string(fl_value_lookup_string(item_value, "type"));
    if (strcmp(type, "separator") == 0) continue;

    FlValue* submenu_value = fl_value_lookup_string(item_value, "submenu");
    if (submenu_value != nullptr && GTK_IS_MENU_ITEM(item)) {
      GtkWidget* sub = gtk_menu_item_get_submenu(GTK_MENU_ITEM(item));
      if (sub != nullptr) {
        _update_menu_labels(sub, submenu_value);
        continue;
      }
    }

    const char* label =
        fl_value_get_string(fl_value_lookup_string(item_value, "label"));
    const char* sublabel = _lookup_string_or_empty(item_value, "sublabel");
    const bool disabled =
        fl_value_get_bool(fl_value_lookup_string(item_value, "disabled"));

    _set_menu_item_text(item, label, sublabel);
    gtk_widget_set_sensitive(item, !disabled);

    if (strcmp(type, "checkbox") == 0 && GTK_IS_CHECK_MENU_ITEM(item)) {
      FlValue* checked_value = fl_value_lookup_string(item_value, "checked");
      if (checked_value != nullptr) {
        const bool checked = fl_value_get_bool(checked_value);
        g_signal_handlers_block_matched(
            item, G_SIGNAL_MATCH_FUNC, 0, 0, nullptr,
            (gpointer)_on_activate, nullptr);
        gtk_check_menu_item_set_active(GTK_CHECK_MENU_ITEM(item), checked);
        g_signal_handlers_unblock_matched(
            item, G_SIGNAL_MATCH_FUNC, 0, 0, nullptr,
            (gpointer)_on_activate, nullptr);
      }
    }
  }
  g_list_free(children);
}

GtkWidget* _create_menu(FlValue* args) {
  FlValue* items_value = fl_value_lookup_string(args, "items");

  GtkWidget* menu = gtk_menu_new();
  for (gint i = 0; i < fl_value_get_length(items_value); i++) {
    FlValue* item_value = fl_value_get_list_value(items_value, i);
    const int id = fl_value_get_int(fl_value_lookup_string(item_value, "id"));
    const char* type =
        fl_value_get_string(fl_value_lookup_string(item_value, "type"));
    const char* label =
        fl_value_get_string(fl_value_lookup_string(item_value, "label"));
    const char* sublabel = _lookup_string_or_empty(item_value, "sublabel");
    const bool disabled =
        fl_value_get_bool(fl_value_lookup_string(item_value, "disabled"));

    gint item_id = id;

    if (strcmp(type, "separator") == 0) {
      gtk_menu_shell_append(GTK_MENU_SHELL(menu),
                            gtk_separator_menu_item_new());
    } else {
      GtkWidget* item = nullptr;
      if (strcmp(type, "checkbox") == 0) {
        item = gtk_check_menu_item_new();
        const auto checked_value =
            fl_value_lookup_string(item_value, "checked");
        if (checked_value != nullptr) {
          const auto checked = fl_value_get_bool(checked_value);
          gtk_check_menu_item_set_active((GtkCheckMenuItem*)item, checked);
        }
      } else {
        item = gtk_menu_item_new();
      }

      gtk_container_add(GTK_CONTAINER(item),
                        _create_menu_item_box(label, sublabel));

      if (disabled) {
        gtk_widget_set_sensitive(item, FALSE);
      }

      if (strcmp(type, "submenu") == 0) {
        GtkWidget* sub_menu =
            _create_menu(fl_value_lookup_string(item_value, "submenu"));
        gtk_menu_item_set_submenu(GTK_MENU_ITEM(item), sub_menu);
      } else {
        g_signal_connect(G_OBJECT(item), "activate", G_CALLBACK(_on_activate),
                         GINT_TO_POINTER(item_id));
      }

      gtk_menu_shell_append(GTK_MENU_SHELL(menu), item);
    }
  }
  return menu;
}

#ifdef HAVE_AYATANA
static void _on_indicator_activate(AppIndicator* indicator, gint x, gint y,
                                   gpointer user_data) {
  fl_method_channel_invoke_method(plugin_instance->channel,
                                  "onTrayIconMouseDown", nullptr, nullptr,
                                  nullptr, nullptr);
}
#endif

static FlMethodResponse* destroy(TrayManagerPlugin* self, FlValue* args) {
  if (!(!indicator)) {
    app_indicator_set_status(indicator, APP_INDICATOR_STATUS_PASSIVE);
  }
  return FL_METHOD_RESPONSE(
      fl_method_success_response_new(fl_value_new_bool(true)));
}

static FlMethodResponse* set_icon(TrayManagerPlugin* self, FlValue* args) {
  const char* id = fl_value_get_string(fl_value_lookup_string(args, "id"));
  const char* icon_path =
      fl_value_get_string(fl_value_lookup_string(args, "iconPath"));

  if (!menu)
    menu = gtk_menu_new();

  if (!indicator) {
    indicator = app_indicator_new(id, icon_path,
                                  APP_INDICATOR_CATEGORY_APPLICATION_STATUS);

#ifdef HAVE_AYATANA
    if (g_signal_lookup("activate", app_indicator_get_type()) != 0) {
      g_signal_connect(G_OBJECT(indicator), "activate", G_CALLBACK(_on_indicator_activate),
                       nullptr);
    }
#endif

    app_indicator_set_menu(indicator, GTK_MENU(menu));
    gtk_widget_show_all(menu);
  }

  app_indicator_set_status(indicator, APP_INDICATOR_STATUS_ACTIVE);
  app_indicator_set_icon_full(indicator, icon_path, "");

  return FL_METHOD_RESPONSE(
      fl_method_success_response_new(fl_value_new_bool(true)));
}

static FlMethodResponse* set_title(TrayManagerPlugin* self, FlValue* args) {
  const char* title =
      fl_value_get_string(fl_value_lookup_string(args, "title"));

  app_indicator_set_label(indicator, title, NULL);

  return FL_METHOD_RESPONSE(
      fl_method_success_response_new(fl_value_new_bool(true)));
}

static FlMethodResponse* set_context_menu(TrayManagerPlugin* self,
                                          FlValue* args) {
  FlValue* keep_open_value = fl_value_lookup_string(args, "keepMenuOpen");
  bool keep_menu_open =
      keep_open_value != nullptr && fl_value_get_bool(keep_open_value);

  if (keep_menu_open && menu != nullptr && is_menu_open_) {
    _update_menu_labels(menu, fl_value_lookup_string(args, "menu"));
  } else {
    if (menu != nullptr) {
      g_signal_handlers_disconnect_by_func(
          menu, (gpointer)_on_menu_mapped, nullptr);
      g_signal_handlers_disconnect_by_func(
          menu, (gpointer)_on_menu_unmapped, nullptr);
    }
    menu = _create_menu(fl_value_lookup_string(args, "menu"));
    g_signal_connect(G_OBJECT(menu), "map",
                     G_CALLBACK(_on_menu_mapped), nullptr);
    g_signal_connect(G_OBJECT(menu), "unmap",
                     G_CALLBACK(_on_menu_unmapped), nullptr);
    app_indicator_set_menu(indicator, GTK_MENU(menu));
    gtk_widget_show_all(menu);
  }

  return FL_METHOD_RESPONSE(
      fl_method_success_response_new(fl_value_new_bool(true)));
}


// Called when a method call is received from Flutter.
static void tray_manager_plugin_handle_method_call(TrayManagerPlugin* self,
                                                   FlMethodCall* method_call) {
  g_autoptr(FlMethodResponse) response = nullptr;

  const gchar* method = fl_method_call_get_name(method_call);
  FlValue* args = fl_method_call_get_args(method_call);

  if (strcmp(method, "destroy") == 0) {
    response = destroy(self, args);
  } else if (strcmp(method, "setIcon") == 0) {
    response = set_icon(self, args);
  } else if (strcmp(method, "setTitle") == 0) {
    response = set_title(self, args);
  } else if (strcmp(method, "setContextMenu") == 0) {
    response = set_context_menu(self, args);
  } else {
    response = FL_METHOD_RESPONSE(fl_method_not_implemented_response_new());
  }

  fl_method_call_respond(method_call, response, nullptr);
}

static void tray_manager_plugin_dispose(GObject* object) {
  G_OBJECT_CLASS(tray_manager_plugin_parent_class)->dispose(object);
}

static void tray_manager_plugin_class_init(TrayManagerPluginClass* klass) {
  G_OBJECT_CLASS(klass)->dispose = tray_manager_plugin_dispose;
}

static void tray_manager_plugin_init(TrayManagerPlugin* self) {}

static void method_call_cb(FlMethodChannel* channel,
                           FlMethodCall* method_call,
                           gpointer user_data) {
  TrayManagerPlugin* plugin = TRAY_MANAGER_PLUGIN(user_data);
  tray_manager_plugin_handle_method_call(plugin, method_call);
}

void tray_manager_plugin_register_with_registrar(FlPluginRegistrar* registrar) {
  TrayManagerPlugin* plugin = TRAY_MANAGER_PLUGIN(
      g_object_new(tray_manager_plugin_get_type(), nullptr));

  plugin->registrar = FL_PLUGIN_REGISTRAR(g_object_ref(registrar));

  g_autoptr(FlStandardMethodCodec) codec = fl_standard_method_codec_new();
  plugin->channel =
      fl_method_channel_new(fl_plugin_registrar_get_messenger(registrar),
                            "tray_manager", FL_METHOD_CODEC(codec));
  fl_method_channel_set_method_call_handler(
      plugin->channel, method_call_cb, g_object_ref(plugin), g_object_unref);

  plugin_instance = plugin;

  g_object_unref(plugin);
}
