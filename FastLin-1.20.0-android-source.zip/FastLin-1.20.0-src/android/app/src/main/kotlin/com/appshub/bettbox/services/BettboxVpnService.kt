package com.appshub.bettbox.services

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ProxyInfo
import android.net.VpnService
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.Parcel
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.appshub.bettbox.GlobalState
import com.appshub.bettbox.core.Core
import com.appshub.bettbox.extensions.getIpv4RouteAddress
import com.appshub.bettbox.extensions.getIpv6RouteAddress
import com.appshub.bettbox.extensions.toCIDR
import com.appshub.bettbox.models.AccessControlMode
import com.appshub.bettbox.models.VpnOptions
import com.appshub.bettbox.plugins.ServicePlugin
import com.appshub.bettbox.plugins.VpnPlugin
import com.appshub.bettbox.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BettboxVpnService : VpnService(), BaseServiceInterface {
    companion object {
        private const val TAG = "BettboxVpnService"
        private val proxyExclusionPattern =
            Regex("[a-zA-Z0-9*]+(-[a-zA-Z0-9*]+)*(\\.[a-zA-Z0-9*]+(-[a-zA-Z0-9*]+)*)*")
    }

    @Volatile
    private var isStopped = false

    @Volatile
    private var hasStartedForeground = false

    private var unlockReceiver: BroadcastReceiver? = null
    private val fairMemoryHelper = FairMemoryHelper(TAG)
    
    @Volatile
    private var isSpeedNotificationEnabled = false

    @Volatile
    private var lastNotificationText: String? = null

    @Volatile
    private var pendingSpeedProfile: String? = null

    @Volatile
    private var pendingSpeedInfo: String? = null

    override fun onCreate() {
        super.onCreate()
        GlobalState.initServiceEngine()

        unlockReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        GlobalState.getCurrentVPNPlugin()?.notifyScreenStateChanged(false)
                        return
                    }
                    Intent.ACTION_SCREEN_ON -> {
                        GlobalState.getCurrentVPNPlugin()?.notifyScreenStateChanged(true)
                    }
                }
                lastNotificationText = null
                resetNotificationBuilder()
                CoroutineScope(Dispatchers.Main).launch {
                    startForeground()
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(unlockReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(unlockReceiver, filter)
        }

        fairMemoryHelper.register(
            context = this,
            onTrim = {
                GlobalState.getCurrentVPNPlugin()?.requestGc()
                Core.purge(all = true)
            },
            onKill = { /* system will kill process; service has no extra state to save */ }
        )
    }

    override suspend fun start(options: VpnOptions): Int = with(Builder()) {
        options.ipv4Address.takeIf { it.isNotEmpty() }?.let { ipv4 ->
            val cidr = ipv4.toCIDR()
            addAddress(cidr.address, cidr.prefixLength)
            Log.d("addAddress", "address: ${cidr.address} prefixLength:${cidr.prefixLength}")
            val routes = options.getIpv4RouteAddress()
            if (routes.isNotEmpty()) {
                runCatching {
                    routes.forEach { addRoute(it.address, it.prefixLength) }
                    if (routes.none { it.address.isAnyLocalAddress }) addRoute("0.0.0.0", 32)
                }.onFailure { addRoute("0.0.0.0", 0) }
            } else {
                addRoute("0.0.0.0", 0)
            }
        } ?: addRoute("0.0.0.0", 0)

        if (options.ipv6Address.isNotEmpty()) {
            runCatching {
                val cidr = options.ipv6Address.toCIDR()
                Log.d("addAddress6", "address: ${cidr.address} prefixLength:${cidr.prefixLength}")
                addAddress(cidr.address, cidr.prefixLength)
                val routes = options.getIpv6RouteAddress()
                if (routes.isNotEmpty()) {
                    runCatching { routes.forEach { addRoute(it.address, it.prefixLength) } }
                        .onFailure { addRoute("::", 0) }
                } else {
                    addRoute("::", 0)
                }
            }.onFailure { Log.d("addAddress6", "IPv6 is not supported.") }
        }

        if (options.dnsServerAddress.isNotBlank()) {
            runCatching { addDnsServer(options.dnsServerAddress) }
                .onFailure { Log.e(TAG, "Invalid DNS: ${options.dnsServerAddress}") }
        }

        setMtu(options.mtu.takeIf { it in 1280..65535 } ?: 9000)

        val accessControl = options.accessControl
        if (accessControl.enable) {
            when (accessControl.mode) {
                AccessControlMode.acceptSelected -> {
                    (accessControl.acceptList + packageName).filter { it.isNotBlank() }.distinct().forEach { appPkg ->
                        runCatching { addAllowedApplication(appPkg) }
                            .onFailure { Log.e(TAG, "Failed to allow package $appPkg: ${it.message}", it) }
                    }
                }
                AccessControlMode.rejectSelected -> (accessControl.rejectList - packageName).filter { it.isNotBlank() }.distinct().forEach { appPkg ->
                    runCatching { addDisallowedApplication(appPkg) }
                        .onFailure { Log.e(TAG, "Failed to disallow package $appPkg: ${it.message}", it) }
                }
            }
        }

        setSession("Bettbox")
        setBlocking(false)
        if (Build.VERSION.SDK_INT >= 29) setMetered(false)
        if (options.allowBypass) allowBypass()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && options.systemProxy && options.port > 0) {
            val exclusionList = options.bypassDomain.filter { proxyExclusionPattern.matches(it) }
            setHttpProxy(ProxyInfo.buildDirectProxy("127.0.0.1", options.port, exclusionList))
        }

        val fd = runCatching { establish()?.detachFd() }.getOrElse { e ->
            ServicePlugin.appWarn(TAG, "Establish VPN failed: ${e.message}")
            null
        }
        if (fd != null && fd > 0) {
            return fd
        }
        Log.e(TAG, "Establish VPN rejected by system")
        -1
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "UPDATE_NOTIFICATION_SPEED") {
            val profileName = intent.getStringExtra("profileName") ?: ""
            val speedInfo = intent.getStringExtra("speedInfo") ?: ""
            isSpeedNotificationEnabled = true
            if (!GlobalState.isSmartStopped && hasStartedForeground) {
                CoroutineScope(Dispatchers.Main).launch {
                    updateNotificationSpeed(profileName, speedInfo)
                }
            }
        }
        return START_STICKY
    }

    internal suspend fun restoreNotification() {
        isSpeedNotificationEnabled = false
        pendingSpeedProfile = null
        pendingSpeedInfo = null
        if (hasStartedForeground) {
            startForeground()
        }
    }

    override fun stop() {
        if (isStopped) return
        isStopped = true
        hasStartedForeground = false
        lastNotificationText = null

        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                stopForeground(true)
            }
        }.onFailure { Log.e(TAG, "Failed to stop foreground: ${it.message}") }

        runCatching {
            getSystemService(android.app.NotificationManager::class.java)
                ?.cancel(GlobalState.NOTIFICATION_ID)
        }.onFailure { Log.e(TAG, "Failed to cancel notification: ${it.message}") }

        stopSelf()
    }

    @Volatile
    private var cachedBuilder: NotificationCompat.Builder? = null

    fun resetNotificationBuilder() {
        cachedBuilder = null
    }

    private suspend fun notificationBuilder(): NotificationCompat.Builder {
        if (cachedBuilder == null) {
            cachedBuilder = createBettboxNotificationBuilder()
        }
        return cachedBuilder!!
    }

    @SuppressLint("ForegroundServiceType")
    override suspend fun startForeground() {
        val isSuspended = GlobalState.isSmartStopped
        val isHighPriority = GlobalState.isNotificationHighPriority
        ensureNotificationChannel(isSuspended, isHighPriority)
        val title: String
        val content: String
        if (isSuspended) {
            title = getString(R.string.core_suspended)
            content = getString(R.string.smart_auto_stop_service_running)
        } else {
            title = getString(R.string.core_connected)
            content = getString(R.string.service_running)
        }

        lastNotificationText = null
        val builder = createBettboxNotificationBuilder(isSuspended, isHighPriority)
        val notification = builder
            .setContentTitle(title)
            .setContentText(content)
            .setStyle(null)
            .build()

        val isFirstTime = !hasStartedForeground
        if (isFirstTime) {
            hasStartedForeground = true
        }

        val pendingProfile = pendingSpeedProfile
        val pendingSpeed = pendingSpeedInfo
        if (!isSuspended && GlobalState.isSpeedNotificationEnabled && pendingProfile != null && pendingSpeed != null) {
            updateNotificationSpeed(pendingProfile, pendingSpeed)
            return
        }

        this.startForeground(notification, useSpecialType = !isSuspended)
    }

    @SuppressLint("ForegroundServiceType")
    internal suspend fun updateNotificationSpeed(profileName: String, speedInfo: String) {
        pendingSpeedProfile = profileName
        pendingSpeedInfo = speedInfo

        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (powerManager?.isInteractive == false) {
            return
        }

        if (GlobalState.isSmartStopped) {
            return
        }

        val combinedText = "$profileName\n$speedInfo"
        if (combinedText == lastNotificationText) {
            return
        }
        lastNotificationText = combinedText

        val builder = notificationBuilder()
        val notification = builder
            .setContentTitle(profileName)
            .setContentText(speedInfo)
            .setStyle(null)
            .build()

        if (!hasStartedForeground) {
            hasStartedForeground = true
            runCatching {
                this.startForeground(notification, useSpecialType = !GlobalState.isSmartStopped)
            }.onFailure { Log.e(TAG, "updateNotificationSpeed startForeground error: ${it.message}") }
        } else {
            runCatching {
                getSystemService(android.app.NotificationManager::class.java)
                    ?.notify(GlobalState.NOTIFICATION_ID, notification)
            }.onFailure { Log.e(TAG, "updateNotificationSpeed notify error: ${it.message}") }
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level == 10 || level == 15 || level >= 40) {
            GlobalState.getCurrentVPNPlugin()?.requestGc()
            GlobalState.notifyLowMemory()
            Core.purge(all = false)
        }
    }

    private val binder = LocalBinder()

    inner class LocalBinder : Binder() {
        fun getService(): BettboxVpnService = this@BettboxVpnService

        override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean =
            runCatching {
                super.onTransact(code, data, reply, flags).also { success ->
                    if (!success) GlobalState.getCurrentTilePlugin()?.handleStop()
                }
            }.getOrElse { Log.e(TAG, "onTransact failed: ${it.message}"); false }
    }

    override fun onBind(intent: Intent?): IBinder? {
        if (intent?.action == VpnService.SERVICE_INTERFACE) {
            return super.onBind(intent)
        }
        return binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        super.onUnbind(intent)
        return true
    }

    override fun onRevoke() {
        ServicePlugin.appWarn(TAG, "VPN revoked by system")
        runCatching {
            VpnPlugin.handleStop()
            getSystemService(android.app.NotificationManager::class.java)
                ?.cancel(GlobalState.NOTIFICATION_ID)
        }.onFailure { Log.e(TAG, "onRevoke error: ${it.message}") }
        super.onRevoke()
    }

    override fun onDestroy() {
        stop()
        unlockReceiver?.let {
            unregisterReceiver(it)
            unlockReceiver = null
        }
        fairMemoryHelper.unregister(this)
        super.onDestroy()
    }
}
