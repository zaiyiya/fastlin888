import 'dart:async';
import 'dart:math';

import 'package:bett_box/common/common.dart';
import 'package:bett_box/plugins/app.dart';
import 'package:bett_box/state.dart';
import 'package:bett_box/widgets/activate_box.dart';
import 'package:material_ui/material_ui.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class ScanPage extends StatefulWidget {
  final bool Function(String value)? accept;

  const ScanPage({super.key, this.accept});

  @override
  State<ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> with WidgetsBindingObserver {
  MobileScannerController controller = MobileScannerController(
    // normal: keep scanning continuously (noDuplicates often misses live camera frames)
    detectionSpeed: DetectionSpeed.normal,
    detectionTimeoutMs: 250,
    formats: const [BarcodeFormat.qrCode],
    autoStart: false,
    // Prefer camera facing back for QR scanning
    facing: CameraFacing.back,
  );

  StreamSubscription<Object?>? _subscription;
  bool _handled = false;
  bool _permissionDenied = false;
  bool _starting = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _subscription = controller.barcodes.listen(_handleBarcode);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.afterRouteTransition(() {
        if (!mounted) return;
        _ensureCameraStarted();
      });
    });
  }

  /// Extract a usable subscription URL from QR payload.
  /// Supports plain http(s) URLs and clash/flclash/bettbox install-config links.
  String? _extractSubscriptionUrl(String raw) {
    final value = raw.trim();
    if (value.isEmpty) return null;
    if (value.isUrl || value.isHttpUrl) return value;

    final uri = Uri.tryParse(value);
    if (uri != null) {
      // clash://install-config?url=...
      if (uri.host == 'install-config' ||
          uri.path.contains('install-config')) {
        final nested = uri.queryParameters['url'];
        if (nested != null && nested.trim().isNotEmpty) {
          return nested.trim();
        }
      }
      // Some panels put the real link in query `url` even on https
      final nested = uri.queryParameters['url'];
      if (nested != null &&
          nested.trim().isNotEmpty &&
          (nested.isUrl || nested.isHttpUrl)) {
        return nested.trim();
      }
    }

    // Fallback: find first http(s) substring in the payload
    final match = RegExp(r'https?://\S+', caseSensitive: false).firstMatch(value);
    if (match != null) return match.group(0);

    return null;
  }

  void _handleBarcode(BarcodeCapture barcodeCapture) {
    if (_handled || barcodeCapture.barcodes.isEmpty) return;
    final rawValue = barcodeCapture.barcodes.first.rawValue?.trim();
    if (rawValue == null || rawValue.isEmpty) return;

    final extracted = _extractSubscriptionUrl(rawValue) ?? rawValue;
    final accepted =
        widget.accept?.call(extracted) ??
        (extracted.isUrl || extracted.isHttpUrl || _extractSubscriptionUrl(rawValue) != null);

    if (!accepted) {
      // Keep scanning — do not pop on a random non-subscription QR
      commonPrint.warn('QR ignored (not a subscription URL): $rawValue');
      return;
    }

    _handled = true;
    unawaited(controller.stop());
    Navigator.pop<String>(context, extracted);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    switch (state) {
      case AppLifecycleState.detached:
      case AppLifecycleState.hidden:
        return;
      case AppLifecycleState.paused:
        // Fully backgrounded: free the camera
        unawaited(_subscription?.cancel());
        _subscription = null;
        if (controller.value.isRunning) {
          unawaited(controller.stop());
        }
        return;
      case AppLifecycleState.resumed:
        _subscription ??= controller.barcodes.listen(_handleBarcode);
        _ensureCameraStarted();
        return;
      case AppLifecycleState.inactive:
        // Do NOT stop camera here — system dialogs / status-bar pull also
        // trigger inactive and would freeze live scanning.
        return;
    }
  }

  Future<void> _ensureCameraStarted() async {
    if (_starting) return;

    _starting = true;
    try {
      if (_permissionDenied && !await app.hasCameraPermission()) {
        return;
      }
      if (!controller.value.isRunning) {
        await controller.start();
      }
      if (!mounted) return;
      final denied =
          controller.value.error?.errorCode ==
          MobileScannerErrorCode.permissionDenied;
      if (denied != _permissionDenied) {
        setState(() {
          _permissionDenied = denied;
        });
      }
    } catch (e) {
      commonPrint.warn('Start camera failed: $e');
    } finally {
      _starting = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    double sideLength = min(400, MediaQuery.sizeOf(context).width * 0.67);
    final scanWindow = Rect.fromCenter(
      center: MediaQuery.sizeOf(context).center(Offset.zero),
      width: sideLength,
      height: sideLength,
    );
    return Scaffold(
      body: Stack(
        children: [
          Center(
            child: MobileScanner(
              controller: controller,
              // Full-frame detection is more reliable than a tight scanWindow
              // on many Android devices; overlay is only visual guidance.
              errorBuilder: (context, error) {
                if (error.errorCode ==
                    MobileScannerErrorCode.permissionDenied) {
                  if (!_starting && !_permissionDenied && mounted) {
                    WidgetsBinding.instance.addPostFrameCallback((_) {
                      if (!mounted) return;
                      setState(() {
                        _permissionDenied = true;
                      });
                    });
                    unawaited(controller.stop());
                  }
                  return _buildPermissionDeniedView(context);
                }
                return _buildErrorView(context, error);
              },
            ),
          ),
          if (_permissionDenied) _buildPermissionDeniedView(context),
          if (!_permissionDenied)
            CustomPaint(painter: ScannerOverlay(scanWindow: scanWindow)),
          AppBar(
            backgroundColor: Colors.transparent,
            automaticallyImplyLeading: false,
            leading: IconButton(
              style: const ButtonStyle(
                iconSize: WidgetStatePropertyAll(32),
                foregroundColor: WidgetStatePropertyAll(Colors.white),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icon(context.resolveIcon(Icons.close)),
            ),
            actions: [
              if (!_permissionDenied)
                ValueListenableBuilder<MobileScannerState>(
                  valueListenable: controller,
                  builder: (context, state, _) {
                    var icon = Icon(context.resolveIcon(Icons.flash_off));
                    var backgroundColor = Colors.black12;
                    switch (state.torchState) {
                      case TorchState.off:
                        icon = Icon(context.resolveIcon(Icons.flash_off));
                        backgroundColor = Colors.black12;
                      case TorchState.on:
                        icon = Icon(context.resolveIcon(Icons.flash_on));
                        backgroundColor = Colors.orange;
                      case TorchState.unavailable:
                        icon = Icon(context.resolveIcon(Icons.flash_off));
                        backgroundColor = Colors.transparent;
                      case TorchState.auto:
                        icon = Icon(context.resolveIcon(Icons.flash_auto));
                        backgroundColor = Colors.orange;
                    }
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 8),
                      child: ActivateBox(
                        active: state.torchState != TorchState.unavailable,
                        child: IconButton(
                          color: Colors.white,
                          icon: icon,
                          style: ButtonStyle(
                            foregroundColor: const WidgetStatePropertyAll(
                              Colors.white,
                            ),
                            backgroundColor: WidgetStatePropertyAll(
                              backgroundColor,
                            ),
                          ),
                          onPressed: () => controller.toggleTorch(),
                        ),
                      ),
                    );
                  },
                ),
            ],
          ),
          if (!_permissionDenied)
            Container(
              margin: const EdgeInsets.only(bottom: 32),
              alignment: Alignment.bottomCenter,
              child: IconButton(
                color: Colors.white,
                style: const ButtonStyle(
                  foregroundColor: WidgetStatePropertyAll(Colors.white),
                  backgroundColor: WidgetStatePropertyAll(Colors.grey),
                ),
                padding: const EdgeInsets.all(16),
                iconSize: 32.0,
                onPressed: globalState.appController.addProfileFormQrCode,
                icon: Icon(context.resolveIcon(Icons.photo_camera_back)),
              ),
            ),
        ],
      ),
    );
  }

  /// 构建权限被拒绝的视图
  Widget _buildPermissionDeniedView(BuildContext context) {
    return Container(
      color: Colors.black,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                context.resolveIcon(Icons.camera_alt_outlined),
                size: 80,
                color: Colors.white54,
              ),
              const SizedBox(height: 24),
              Text(
                appLocalizations.cameraPermissionDenied,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                appLocalizations.cameraPermissionDesc,
                style: const TextStyle(color: Colors.white70, fontSize: 14),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Build error view
  Widget _buildErrorView(BuildContext context, MobileScannerException error) {
    String errorMessage = 'Camera init failed';
    switch (error.errorCode) {
      case MobileScannerErrorCode.controllerUninitialized:
        errorMessage = 'Camera uninitialized';
        break;
      case MobileScannerErrorCode.genericError:
        errorMessage = 'Camera error';
        break;
      case MobileScannerErrorCode.unsupported:
        errorMessage = 'Scan not supported';
        break;
      default:
        errorMessage = error.errorDetails?.message ?? 'Unknown error';
    }

    return Container(
      color: Colors.black,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                context.resolveIcon(Icons.error_outline),
                size: 80,
                color: Colors.red,
              ),
              const SizedBox(height: 24),
              Text(
                errorMessage,
                style: const TextStyle(color: Colors.white, fontSize: 16),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    unawaited(_subscription?.cancel());
    _subscription = null;
    unawaited(controller.dispose());
    super.dispose();
  }
}

class ScannerOverlay extends CustomPainter {
  const ScannerOverlay({required this.scanWindow, this.borderRadius = 12.0});

  final Rect scanWindow;
  final double borderRadius;

  @override
  void paint(Canvas canvas, Size size) {
    final backgroundPath = Path()..addRect(Rect.largest);

    final cutoutPath = Path()
      ..addRRect(
        RRect.fromRectAndCorners(
          scanWindow,
          topLeft: Radius.circular(borderRadius),
          topRight: Radius.circular(borderRadius),
          bottomLeft: Radius.circular(borderRadius),
          bottomRight: Radius.circular(borderRadius),
        ),
      );

    final backgroundPaint = Paint()
      ..color = Colors.black.opacity50
      ..style = PaintingStyle.fill
      ..blendMode = BlendMode.dstOut;

    final backgroundWithCutout = Path.combine(
      PathOperation.difference,
      backgroundPath,
      cutoutPath,
    );

    final borderPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.0;

    final borderRect = RRect.fromRectAndCorners(
      scanWindow,
      topLeft: Radius.circular(borderRadius),
      topRight: Radius.circular(borderRadius),
      bottomLeft: Radius.circular(borderRadius),
      bottomRight: Radius.circular(borderRadius),
    );

    canvas.drawPath(backgroundWithCutout, backgroundPaint);
    canvas.drawRRect(borderRect, borderPaint);
  }

  @override
  bool shouldRepaint(ScannerOverlay oldDelegate) {
    return scanWindow != oldDelegate.scanWindow ||
        borderRadius != oldDelegate.borderRadius;
  }
}
