/// FastLin: subscription lock.
///
/// Only subscription links served from the hosts below (or their sub-domains)
/// can be imported. Add every domain your panel serves subscriptions from.
const List<String> fastLinSubscriptionHosts = <String>[
  'fastlin.live',
  'zongdaili.xyz',
];

const String fastLinOnlyMessage =
    '仅支持导入 FastLin 官方订阅链接或二维码\n'
    'Only FastLin subscription links or QR codes can be imported';

bool isFastLinSubscriptionUrl(String url) {
  final uri = Uri.tryParse(url.trim());
  if (uri == null) return false;
  if (uri.scheme != 'https' && uri.scheme != 'http') return false;
  final host = uri.host.toLowerCase();
  if (host.isEmpty) return false;
  for (final domain in fastLinSubscriptionHosts) {
    if (host == domain || host.endsWith('.$domain')) return true;
  }
  return false;
}

/// Throws [fastLinOnlyMessage] when [url] is not a FastLin subscription.
void ensureFastLinSubscription(String url) {
  if (!isFastLinSubscriptionUrl(url)) throw fastLinOnlyMessage;
}

/// FastLin: stable gradient index for a node, grouped by region so every
/// country keeps its own colour. Falls back to a hash of the name.
final List<(int, RegExp)> _fastLinRegionRules = <(int, RegExp)>[
  (0, RegExp(r'日本|japan|东京|大阪|(^|[^a-z])jp([^a-z]|$)')),
  (4, RegExp(r'韩国|韓國|korea|首尔|(^|[^a-z])kr([^a-z]|$)')),
  (1, RegExp(r'新加坡|狮城|singapore|(^|[^a-z])sg([^a-z]|$)')),
  (
    2,
    RegExp(r'美国|美國|united states|洛杉矶|纽约|硅谷|西雅图|(^|[^a-z])(us|usa)([^a-z]|$)'),
  ),
  (3, RegExp(r'香港|hong kong|(^|[^a-z])hk([^a-z]|$)')),
  (5, RegExp(r'台湾|台灣|taiwan|(^|[^a-z])tw([^a-z]|$)')),
  (6, RegExp(r'英国|德国|法国|荷兰|欧洲|europe|(^|[^a-z])(uk|de|fr|nl)([^a-z]|$)')),
  (7, RegExp(r'马来|泰国|越南|印度|菲律宾|印尼|澳|加拿大|俄罗斯|土耳其')),
];

int fastLinNodeGradientIndex(String name) {
  final lower = name.toLowerCase();
  for (final (index, pattern) in _fastLinRegionRules) {
    if (pattern.hasMatch(lower)) return index;
  }
  var hash = 0;
  for (final unit in lower.codeUnits) {
    hash = (hash * 31 + unit) & 0x7fffffff;
  }
  return hash % 8;
}

/// Proxy types that are groups or built-ins, not real nodes.
const Set<String> _fastLinNonNodeTypes = <String>{
  'selector',
  'urltest',
  'fallback',
  'loadbalance',
  'relay',
  'direct',
  'reject',
  'rejectdrop',
  'pass',
  'compatible',
  'rematch',
};

/// True when an entry of the GLOBAL list is a real node the user can pick.
bool isFastLinManualNode(String name, String type) {
  if (_fastLinNonNodeTypes.contains(type.toLowerCase().replaceAll('-', ''))) {
    return false;
  }
  switch (name.toUpperCase()) {
    case 'DIRECT':
    case 'REJECT':
    case 'REJECT-DROP':
    case 'PASS':
    case 'COMPATIBLE':
      return false;
  }
  return true;
}
