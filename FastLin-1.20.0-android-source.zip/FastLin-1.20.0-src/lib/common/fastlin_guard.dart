/// FastLin: subscription lock.
///
/// Only subscription links served from the hosts below (or their sub-domains)
/// can be imported. Add every domain your panel serves subscriptions from.
const List<String> fastLinSubscriptionHosts = <String>[
  'fastlin.live',
  'zongdaili.xyz',
];

const String fastLinOnlyMessage =
    '仅支持导入 FastLin 官方订阅链接或二维码\n'
    'Only FastLin subscription links or QR codes can be imported';

bool isFastLinSubscriptionUrl(String url) {
  final uri = Uri.tryParse(url.trim());
  if (uri == null) return false;
  if (uri.scheme != 'https' && uri.scheme != 'http') return false;
  final host = uri.host.toLowerCase();
  if (host.isEmpty) return false;
  for (final domain in fastLinSubscriptionHosts) {
    if (host == domain || host.endsWith('.$domain')) return true;
  }
  return false;
}

/// Throws [fastLinOnlyMessage] when [url] is not a FastLin subscription.
void ensureFastLinSubscription(String url) {
  if (!isFastLinSubscriptionUrl(url)) throw fastLinOnlyMessage;
}
