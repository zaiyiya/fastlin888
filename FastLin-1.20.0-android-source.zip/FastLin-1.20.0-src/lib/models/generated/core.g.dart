// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../core.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_SetupParams _$SetupParamsFromJson(Map<String, dynamic> json) => _SetupParams(
  selectedMap: Map<String, String>.from(json['selected-map'] as Map),
  testUrl: json['test-url'] as String,
  profilePath: json['profile-path'] as String? ?? '',
  ageSecretKey: json['age-secret-key'] as String? ?? '',
  scriptedConfig: json['scripted-config'] as String? ?? '',
  patch: json['patch'] as Map<String, dynamic>?,
);

Map<String, dynamic> _$SetupParamsToJson(_SetupParams instance) =>
    <String, dynamic>{
      'selected-map': instance.selectedMap,
      'test-url': instance.testUrl,
      'profile-path': instance.profilePath,
      'age-secret-key': instance.ageSecretKey,
      'scripted-config': instance.scriptedConfig,
      'patch': instance.patch,
    };

_SetupResult _$SetupResultFromJson(Map<String, dynamic> json) => _SetupResult(
  message: json['message'] as String? ?? '',
  global: json['global'] as String? ?? '',
);

Map<String, dynamic> _$SetupResultToJson(_SetupResult instance) =>
    <String, dynamic>{'message': instance.message, 'global': instance.global};

_UpdateParams _$UpdateParamsFromJson(Map<String, dynamic> json) =>
    _UpdateParams(
      tun: Tun.fromJson(json['tun'] as Map<String, dynamic>),
      mixedPort: (json['mixed-port'] as num).toInt(),
      allowLan: json['allow-lan'] as bool,
      findProcessMode: $enumDecode(
        _$FindProcessModeEnumMap,
        json['find-process-mode'],
      ),
      mode: $enumDecode(_$ModeEnumMap, json['mode']),
      logLevel: $enumDecode(_$LogLevelEnumMap, json['log-level']),
      ipv6: json['ipv6'] as bool,
      tcpConcurrent: json['tcp-concurrent'] as bool,
      externalController: json['external-controller'] as String,
      unifiedDelay: json['unified-delay'] as bool,
    );

Map<String, dynamic> _$UpdateParamsToJson(_UpdateParams instance) =>
    <String, dynamic>{
      'tun': instance.tun,
      'mixed-port': instance.mixedPort,
      'allow-lan': instance.allowLan,
      'find-process-mode': _$FindProcessModeEnumMap[instance.findProcessMode]!,
      'mode': _$ModeEnumMap[instance.mode]!,
      'log-level': _$LogLevelEnumMap[instance.logLevel]!,
      'ipv6': instance.ipv6,
      'tcp-concurrent': instance.tcpConcurrent,
      'external-controller': instance.externalController,
      'unified-delay': instance.unifiedDelay,
    };

const _$FindProcessModeEnumMap = {
  FindProcessMode.always: 'always',
  FindProcessMode.strict: 'strict',
  FindProcessMode.off: 'off',
};

const _$ModeEnumMap = {
  Mode.rule: 'rule',
  Mode.global: 'global',
  Mode.direct: 'direct',
};

const _$LogLevelEnumMap = {
  LogLevel.debug: 'debug',
  LogLevel.info: 'info',
  LogLevel.warning: 'warning',
  LogLevel.error: 'error',
  LogLevel.silent: 'silent',
};

_CoreState _$CoreStateFromJson(Map<String, dynamic> json) => _CoreState(
  vpnProps: VpnProps.fromJson(json['vpn-props'] as Map<String, dynamic>),
  onlyStatisticsProxy: json['only-statistics-proxy'] as bool,
  currentProfileName: json['current-profile-name'] as String,
  bypassDomain:
      (json['bypass-domain'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList() ??
      const [],
  trafficStats: TrafficStatsOptions.fromJson(
    json['traffic-stats'] as Map<String, dynamic>,
  ),
);

Map<String, dynamic> _$CoreStateToJson(_CoreState instance) =>
    <String, dynamic>{
      'vpn-props': instance.vpnProps,
      'only-statistics-proxy': instance.onlyStatisticsProxy,
      'current-profile-name': instance.currentProfileName,
      'bypass-domain': instance.bypassDomain,
      'traffic-stats': instance.trafficStats,
    };

_AndroidVpnOptions _$AndroidVpnOptionsFromJson(Map<String, dynamic> json) =>
    _AndroidVpnOptions(
      enable: json['enable'] as bool,
      port: (json['port'] as num).toInt(),
      accessControl: json['accessControl'] == null
          ? null
          : AccessControl.fromJson(
              json['accessControl'] as Map<String, dynamic>,
            ),
      allowBypass: json['allowBypass'] as bool,
      systemProxy: json['systemProxy'] as bool,
      bypassDomain: (json['bypassDomain'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
      ipv4Address: json['ipv4Address'] as String,
      ipv6Address: json['ipv6Address'] as String,
      routeAddress:
          (json['routeAddress'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const [],
      routeMode: json['routeMode'] as String? ?? 'config',
      dnsServerAddress: json['dnsServerAddress'] as String,
      dozeSuspend: json['dozeSuspend'] as bool? ?? false,
      mtu: (json['mtu'] as num?)?.toInt() ?? 9000,
    );

Map<String, dynamic> _$AndroidVpnOptionsToJson(_AndroidVpnOptions instance) =>
    <String, dynamic>{
      'enable': instance.enable,
      'port': instance.port,
      'accessControl': instance.accessControl,
      'allowBypass': instance.allowBypass,
      'systemProxy': instance.systemProxy,
      'bypassDomain': instance.bypassDomain,
      'ipv4Address': instance.ipv4Address,
      'ipv6Address': instance.ipv6Address,
      'routeAddress': instance.routeAddress,
      'routeMode': instance.routeMode,
      'dnsServerAddress': instance.dnsServerAddress,
      'dozeSuspend': instance.dozeSuspend,
      'mtu': instance.mtu,
    };

_InitParams _$InitParamsFromJson(Map<String, dynamic> json) => _InitParams(
  homeDir: json['home-dir'] as String,
  version: (json['version'] as num).toInt(),
);

Map<String, dynamic> _$InitParamsToJson(_InitParams instance) =>
    <String, dynamic>{
      'home-dir': instance.homeDir,
      'version': instance.version,
    };

_ChangeProxyParams _$ChangeProxyParamsFromJson(Map<String, dynamic> json) =>
    _ChangeProxyParams(
      groupName: json['group-name'] as String,
      proxyName: json['proxy-name'] as String,
    );

Map<String, dynamic> _$ChangeProxyParamsToJson(_ChangeProxyParams instance) =>
    <String, dynamic>{
      'group-name': instance.groupName,
      'proxy-name': instance.proxyName,
    };

_UpdateGeoDataParams _$UpdateGeoDataParamsFromJson(Map<String, dynamic> json) =>
    _UpdateGeoDataParams(
      geoType: json['geo-type'] as String,
      geoName: json['geo-name'] as String,
    );

Map<String, dynamic> _$UpdateGeoDataParamsToJson(
  _UpdateGeoDataParams instance,
) => <String, dynamic>{
  'geo-type': instance.geoType,
  'geo-name': instance.geoName,
};

_AppMessage _$AppMessageFromJson(Map<String, dynamic> json) => _AppMessage(
  type: $enumDecode(_$AppMessageTypeEnumMap, json['type']),
  data: json['data'],
);

Map<String, dynamic> _$AppMessageToJson(_AppMessage instance) =>
    <String, dynamic>{
      'type': _$AppMessageTypeEnumMap[instance.type]!,
      'data': instance.data,
    };

const _$AppMessageTypeEnumMap = {
  AppMessageType.log: 'log',
  AppMessageType.delays: 'delays',
  AppMessageType.groupsChanged: 'groupsChanged',
  AppMessageType.request: 'request',
  AppMessageType.speedTest: 'speedTest',
  AppMessageType.stunTest: 'stunTest',
  AppMessageType.iperf: 'iperf',
  AppMessageType.localPing: 'localPing',
};

_InvokeMessage _$InvokeMessageFromJson(Map<String, dynamic> json) =>
    _InvokeMessage(
      type: $enumDecode(_$InvokeMessageTypeEnumMap, json['type']),
      data: json['data'],
    );

Map<String, dynamic> _$InvokeMessageToJson(_InvokeMessage instance) =>
    <String, dynamic>{
      'type': _$InvokeMessageTypeEnumMap[instance.type]!,
      'data': instance.data,
    };

const _$InvokeMessageTypeEnumMap = {
  InvokeMessageType.protect: 'protect',
  InvokeMessageType.process: 'process',
};

_Delay _$DelayFromJson(Map<String, dynamic> json) => _Delay(
  name: json['name'] as String,
  url: json['url'] as String,
  value: (json['value'] as num?)?.toInt(),
);

Map<String, dynamic> _$DelayToJson(_Delay instance) => <String, dynamic>{
  'name': instance.name,
  'url': instance.url,
  'value': instance.value,
};

_Now _$NowFromJson(Map<String, dynamic> json) =>
    _Now(name: json['name'] as String, value: json['value'] as String);

Map<String, dynamic> _$NowToJson(_Now instance) => <String, dynamic>{
  'name': instance.name,
  'value': instance.value,
};

_ProviderSubscriptionInfo _$ProviderSubscriptionInfoFromJson(
  Map<String, dynamic> json,
) => _ProviderSubscriptionInfo(
  upload: (json['UPLOAD'] as num?)?.toInt() ?? 0,
  download: (json['DOWNLOAD'] as num?)?.toInt() ?? 0,
  total: (json['TOTAL'] as num?)?.toInt() ?? 0,
  expire: (json['EXPIRE'] as num?)?.toInt() ?? 0,
);

Map<String, dynamic> _$ProviderSubscriptionInfoToJson(
  _ProviderSubscriptionInfo instance,
) => <String, dynamic>{
  'UPLOAD': instance.upload,
  'DOWNLOAD': instance.download,
  'TOTAL': instance.total,
  'EXPIRE': instance.expire,
};

_ExternalProvider _$ExternalProviderFromJson(Map<String, dynamic> json) =>
    _ExternalProvider(
      name: json['name'] as String,
      type: json['type'] as String,
      path: json['path'] as String?,
      count: (json['count'] as num).toInt(),
      subscriptionInfo: subscriptionInfoFormCore(
        json['subscription-info'] as Map<String, Object?>?,
      ),
      isUpdating: json['isUpdating'] as bool? ?? false,
      expanded: json['expanded'] as bool? ?? false,
      interval: (json['interval'] as num?)?.toInt() ?? 0,
      vehicleType: json['vehicle-type'] as String,
      updateAt: DateTime.parse(json['update-at'] as String),
    );

Map<String, dynamic> _$ExternalProviderToJson(_ExternalProvider instance) =>
    <String, dynamic>{
      'name': instance.name,
      'type': instance.type,
      'path': instance.path,
      'count': instance.count,
      'subscription-info': instance.subscriptionInfo,
      'isUpdating': instance.isUpdating,
      'expanded': instance.expanded,
      'interval': instance.interval,
      'vehicle-type': instance.vehicleType,
      'update-at': instance.updateAt.toIso8601String(),
    };

_Action _$ActionFromJson(Map<String, dynamic> json) => _Action(
  method: $enumDecode(_$ActionMethodEnumMap, json['method']),
  data: json['data'],
  id: json['id'] as String,
);

Map<String, dynamic> _$ActionToJson(_Action instance) => <String, dynamic>{
  'method': _$ActionMethodEnumMap[instance.method]!,
  'data': instance.data,
  'id': instance.id,
};

const _$ActionMethodEnumMap = {
  ActionMethod.message: 'message',
  ActionMethod.initClash: 'initClash',
  ActionMethod.getIsInit: 'getIsInit',
  ActionMethod.forceGc: 'forceGc',
  ActionMethod.shutdown: 'shutdown',
  ActionMethod.validateConfig: 'validateConfig',
  ActionMethod.importProfile: 'importProfile',
  ActionMethod.downloadProfile: 'downloadProfile',
  ActionMethod.updateConfig: 'updateConfig',
  ActionMethod.getConfig: 'getConfig',
  ActionMethod.getRuntimeConfig: 'getRuntimeConfig',
  ActionMethod.getProxyConfig: 'getProxyConfig',
  ActionMethod.updateExpandedProvider: 'updateExpandedProvider',
  ActionMethod.exportConfig: 'exportConfig',
  ActionMethod.mergeProfiles: 'mergeProfiles',
  ActionMethod.getProxies: 'getProxies',
  ActionMethod.changeProxy: 'changeProxy',
  ActionMethod.getTraffic: 'getTraffic',
  ActionMethod.getTrafficSnapshot: 'getTrafficSnapshot',
  ActionMethod.resetTraffic: 'resetTraffic',
  ActionMethod.asyncTestDelay: 'asyncTestDelay',
  ActionMethod.asyncTestDelays: 'asyncTestDelays',
  ActionMethod.setForeground: 'setForeground',
  ActionMethod.getConnections: 'getConnections',
  ActionMethod.getConnectionsSummary: 'getConnectionsSummary',
  ActionMethod.closeConnections: 'closeConnections',
  ActionMethod.resetConnections: 'resetConnections',
  ActionMethod.closeConnection: 'closeConnection',
  ActionMethod.closeGroupConnections: 'closeGroupConnections',
  ActionMethod.getDialerDependents: 'getDialerDependents',
  ActionMethod.checkDialerUdp: 'checkDialerUdp',
  ActionMethod.getExternalProviders: 'getExternalProviders',
  ActionMethod.getExternalProvider: 'getExternalProvider',
  ActionMethod.updateGeoData: 'updateGeoData',
  ActionMethod.updateExternalProvider: 'updateExternalProvider',
  ActionMethod.sideLoadExternalProvider: 'sideLoadExternalProvider',
  ActionMethod.startLog: 'startLog',
  ActionMethod.stopLog: 'stopLog',
  ActionMethod.getLogs: 'getLogs',
  ActionMethod.clearLogs: 'clearLogs',
  ActionMethod.startTrackRequests: 'startTrackRequests',
  ActionMethod.stopTrackRequests: 'stopTrackRequests',
  ActionMethod.getRequests: 'getRequests',
  ActionMethod.clearRequests: 'clearRequests',
  ActionMethod.startListener: 'startListener',
  ActionMethod.stopListener: 'stopListener',
  ActionMethod.getCountryCode: 'getCountryCode',
  ActionMethod.getMemory: 'getMemory',
  ActionMethod.crash: 'crash',
  ActionMethod.setupConfig: 'setupConfig',
  ActionMethod.flushFakeIP: 'flushFakeIP',
  ActionMethod.flushDnsCache: 'flushDnsCache',
  ActionMethod.generateAgeKeyPair: 'generateAgeKeyPair',
  ActionMethod.convertAgeSecretKeyToPublicKey: 'convertAgeSecretKeyToPublicKey',
  ActionMethod.decryptAgeConfig: 'decryptAgeConfig',
  ActionMethod.getMode: 'getMode',
  ActionMethod.parseExternalProviderContent: 'parseExternalProviderContent',
  ActionMethod.getCoreStatus: 'getCoreStatus',
  ActionMethod.getInterfaces: 'getInterfaces',
  ActionMethod.startSpeedTest: 'startSpeedTest',
  ActionMethod.cancelSpeedTest: 'cancelSpeedTest',
  ActionMethod.probeSpeedTest: 'probeSpeedTest',
  ActionMethod.getSpeedTestServers: 'getSpeedTestServers',
  ActionMethod.startStunTest: 'startStunTest',
  ActionMethod.cancelStunTest: 'cancelStunTest',
  ActionMethod.routeTrace: 'routeTrace',
  ActionMethod.dnsQuery: 'dnsQuery',
  ActionMethod.mrsPrepare: 'mrsPrepare',
  ActionMethod.mrsLookup: 'mrsLookup',
  ActionMethod.mrsDump: 'mrsDump',
  ActionMethod.cancelMrsLookup: 'cancelMrsLookup',
  ActionMethod.getTrafficStats: 'getTrafficStats',
  ActionMethod.clearTrafficStats: 'clearTrafficStats',
  ActionMethod.storeGet: 'storeGet',
  ActionMethod.storeSet: 'storeSet',
  ActionMethod.storeList: 'storeList',
  ActionMethod.storeClear: 'storeClear',
  ActionMethod.startToolProxy: 'startToolProxy',
  ActionMethod.stopToolProxy: 'stopToolProxy',
  ActionMethod.ageCrypt: 'ageCrypt',
  ActionMethod.startIperfServer: 'startIperfServer',
  ActionMethod.stopIperfServer: 'stopIperfServer',
  ActionMethod.startIperfClient: 'startIperfClient',
  ActionMethod.cancelIperfClient: 'cancelIperfClient',
  ActionMethod.startLocalPing: 'startLocalPing',
  ActionMethod.cancelLocalPing: 'cancelLocalPing',
  ActionMethod.parseNodes: 'parseNodes',
  ActionMethod.registerWarp: 'registerWarp',
  ActionMethod.testNode: 'testNode',
  ActionMethod.setState: 'setState',
  ActionMethod.startTun: 'startTun',
  ActionMethod.stopTun: 'stopTun',
  ActionMethod.getRunTime: 'getRunTime',
  ActionMethod.updateDns: 'updateDns',
  ActionMethod.getAndroidVpnOptions: 'getAndroidVpnOptions',
  ActionMethod.getCurrentProfileName: 'getCurrentProfileName',
};

_ActionResult _$ActionResultFromJson(Map<String, dynamic> json) =>
    _ActionResult(
      method: $enumDecode(_$ActionMethodEnumMap, json['method']),
      data: json['data'],
      id: json['id'] as String?,
      code:
          $enumDecodeNullable(_$ResultTypeEnumMap, json['code']) ??
          ResultType.success,
    );

Map<String, dynamic> _$ActionResultToJson(_ActionResult instance) =>
    <String, dynamic>{
      'method': _$ActionMethodEnumMap[instance.method]!,
      'data': instance.data,
      'id': instance.id,
      'code': _$ResultTypeEnumMap[instance.code]!,
    };

const _$ResultTypeEnumMap = {ResultType.success: 0, ResultType.error: -1};

_ConnectionsSummary _$ConnectionsSummaryFromJson(Map<String, dynamic> json) =>
    _ConnectionsSummary(
      total: (json['total'] as num?)?.toInt() ?? 0,
      tcp: (json['tcp'] as num?)?.toInt() ?? 0,
      udp: (json['udp'] as num?)?.toInt() ?? 0,
      fcmStart: (json['fcm-start'] as num?)?.toInt() ?? 0,
    );

Map<String, dynamic> _$ConnectionsSummaryToJson(_ConnectionsSummary instance) =>
    <String, dynamic>{
      'total': instance.total,
      'tcp': instance.tcp,
      'udp': instance.udp,
      'fcm-start': instance.fcmStart,
    };

_CoreStatus _$CoreStatusFromJson(Map<String, dynamic> json) => _CoreStatus(
  physical: (json['physical'] as num?)?.toInt() ?? 0,
  inUse: (json['in-use'] as num?)?.toInt() ?? 0,
  reclaimable: (json['reclaimable'] as num?)?.toInt() ?? 0,
  goroutines: (json['goroutines'] as num?)?.toInt() ?? 0,
  heapObjects: (json['heap-objects'] as num?)?.toInt() ?? 0,
  lastGC: (json['last-gc'] as num?)?.toInt() ?? 0,
  rules: (json['rules'] as num?)?.toInt() ?? 0,
  proxies: (json['proxies'] as num?)?.toInt() ?? 0,
  proxyGroups: (json['proxy-groups'] as num?)?.toInt() ?? 0,
  ruleProviders: (json['rule-providers'] as num?)?.toInt() ?? 0,
  proxyProviders: (json['proxy-providers'] as num?)?.toInt() ?? 0,
  geodataUse: json['geodata-use'] as String? ?? 'None',
);

Map<String, dynamic> _$CoreStatusToJson(_CoreStatus instance) =>
    <String, dynamic>{
      'physical': instance.physical,
      'in-use': instance.inUse,
      'reclaimable': instance.reclaimable,
      'goroutines': instance.goroutines,
      'heap-objects': instance.heapObjects,
      'last-gc': instance.lastGC,
      'rules': instance.rules,
      'proxies': instance.proxies,
      'proxy-groups': instance.proxyGroups,
      'rule-providers': instance.ruleProviders,
      'proxy-providers': instance.proxyProviders,
      'geodata-use': instance.geodataUse,
    };
